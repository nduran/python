from Tkinter import *

ventana = Tk()
ventana.title("gsef")
ventana.geometry(   '450x300+200+200')
ventana.mainloop()
